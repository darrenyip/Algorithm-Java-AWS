
package csi403;

/**
 * Created by zhangyu ye on 3/28/2018.
 */


public class HashNode<K ,V> {
    K key;
    V value;
    HashNode<K, V>next;
    public HashNode()
    {
        this.key=key;
        this.value=value;
    }

}