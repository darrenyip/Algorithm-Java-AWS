package csi403;

import java.util.ArrayList;

/**
 * Created by zhangyu ye on 3/28/2018.
 */
public class InList {
    private ArrayList<String> inList;

    public InList() {
    }

    public ArrayList<String> getInList() {

        return inList;

    }

    public void setInList(ArrayList<String> inList) {

        this.inList = inList;
    }

}
